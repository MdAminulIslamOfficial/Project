# Inventory-Management-Android-app-
Inventory Management System using android platform and firebase database. Using Barcode and QrCode Scanner
.I have attached json file for firebase database

![](Screenshot_1588806265.png)

![](Screenshot_1588806270.png)
